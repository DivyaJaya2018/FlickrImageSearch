//
//  FlickrImageView.swift
//  FlickrImageSearch
//
//  Created by divyajayaseelan on 11/18/24.
//

import SwiftUI


struct FlickrImageView: View {
    @StateObject private var viewModel = FlickrImageViewModel()

    var body: some View {
        
        NavigationView {
            
            VStack {
                // Search Bar
                TextField("Search for images...", text: $viewModel.searchQuery)
                .padding()
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .frame(height: 40)

                // Loading Indicator
                if viewModel.isLoading {
                ProgressView("Loading...")
                    .progressViewStyle(CircularProgressViewStyle())
                }
                if let errorMessage = viewModel.errorMesssage {
                    Text(errorMessage)
                        .foregroundColor(.red)
                        .padding()
                }
                // Image Grid
                ScrollView {
                    
                    if !viewModel.isLoading {
                        
                        LazyVGrid(columns: [GridItem(.adaptive(minimum: 150))], spacing: 10) {
                            ForEach(0..<viewModel.images.count) { index in
                                withAnimation {
                                    NavigationLink(destination: DetailFlickrImageView(flickrDetailModel: viewModel.images[index])) {
                                        ImageThumbnailView(image: viewModel.images[index])
                                        
                                    }
                                }
                            }
                        }
                        .padding()
                    }
                }
            }
           .navigationTitle("Flickr Image Search")
       }
    }
}
struct ImageThumbnailView: View {
    var image: FlickrImageModel
    
    var body: some View {
        AsyncImage(url: URL(string: image.media.m)) { phase in
            switch phase {
            case .success(let image):
                image.resizable()
                    .scaledToFit()
                    .frame(width: 150, height: 150)
            case .failure:
                Color.gray.frame(width: 150, height: 150)
            case .empty:
                Color.gray.frame(width: 150, height: 150)
            default:
                fatalError()
            }
        }
        .clipShape(RoundedRectangle(cornerRadius: 10))
    }
}

#Preview {
    FlickrImageView()
}

               
