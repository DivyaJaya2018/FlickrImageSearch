//
//  FlickrImageSearchApp.swift
//  FlickrImageSearch
//
//  Created by divyajayaseelan on 11/18/24.
//

import SwiftUI

@main
struct FlickrImageSearchApp: App {
    var body: some Scene {
        WindowGroup {
            FlickrImageView()
        }
    }
}
